#ifndef CURSSTAT_H
#define CURSSTAT_H


/* Global declarations */

void curses_update_stats(boolean redraw);

void curses_decrement_highlight(void);


#endif  /* CURSSTAT_H */
